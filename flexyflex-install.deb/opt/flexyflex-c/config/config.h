#define CLEAR_SIZE 			50
#define PATTERN 				"@"
#define PATTERN_LENGTH	30
#define HEADER_LABEL		"MENU"
