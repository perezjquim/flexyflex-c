

void bosta();
void bosta2();
menu_option options[];
size_t options_length;
