#include "flexyflex.h"

int main()
{
	menu(options,options_length);
	printf("%s\n","Press any key to continue.");	
	ask();
	return 0;
}
